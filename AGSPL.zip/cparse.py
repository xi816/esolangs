import os
import copy
import math
import random

from asplblock import CodeBlock

code = """~$.{$}{.}#"""
temp = ["", "", ""]
Stack = []
Variables = {}

def aspl_map(arr, block):
    global Stack
    narr = []
    for i in arr:
        Stack.append(i)
        aspl_parse(block.code)
        narr.append(Stack[-1])
        Stack.pop()
    return narr

def list_gr(l1, l2):
    narr = []
    for i, j in list(zip(l1, l2)):
        narr.append(int(i < j))
    return narr

def list_lt(l1, l2):
    narr = []
    for i, j in list(zip(l1, l2)):
        narr.append(int(i > j))
    return narr

def aspl_ssplit(string, ln):
    return [string[i:i+ln] for i in range(0, len(string), ln)]


def aspl_parse(cd):
    global Stack, Variables, temp
    c = list(cd) + ["EOF"]
    pos = 0

    while c[pos] != "EOF":
        if c[pos:pos+2] == ["\\", "["]:
            while c[pos:pos+2] != ["]", "\\"]:
                pos += 1

        elif c[pos] in "0123456789":
            while c[pos] in "0123456789":
                temp[0] += c[pos]
                pos += 1
            pos -= 1
            Stack.append(int(temp[0]))
            temp[0] = ""

        elif c[pos] == "\"":
            pos += 1
            while c[pos] != "\"":
                temp[0] += c[pos]
                pos += 1
            Stack.append(temp[0])
            temp[0] = ""

        elif c[pos] == "'":
            pos += 1
            while c[pos] != "'":
                temp[0] += c[pos]
                pos += 1
            Stack.append("".join([chr(ord(i)%256) for i in temp[0]]))
            temp[0] = ""

        elif c[pos] == "+":
            if (type(Stack[-2]) == int and type(Stack[-1]) == int) or \
                (type(Stack[-2]) == list and type(Stack[-1]) == list):
                Stack[-2] += Stack[-1]
                Stack.pop()
            elif type(Stack[-2]) == list and type(Stack[-1]) == int:
                Stack[-2].append(Stack[-1])
                Stack.pop()
            elif type(Stack[-2]) == list and type(Stack[-1]) == CodeBlock:
                Stack[-2] = aspl_map(Stack[-2], Stack[-1])
                Stack.pop()
            elif type(Stack[-2]) == str and type(Stack[-1]) == list:
                Stack[-2] += "".join(str(i) for i in Stack[-1])
                Stack.pop()
            elif type(Stack[-2]) == str and type(Stack[-1]) == int:
                Stack[-2] = "".join([chr(ord(i)+Stack[-1]) for i in Stack[-2]])
                Stack.pop()
    

        elif c[pos] == "-":
            if type(Stack[-2]) == int and type(Stack[-1]) == int:
                Stack[-2] -= Stack[-1]
                Stack.pop()
            elif type(Stack[-2]) == str and type(Stack[-1]) == int:
                Stack[-2] = Stack[-2][:-Stack[-1]]
                Stack.pop()
            elif type(Stack[-2]) == list and type(Stack[-1]) == int:
                for i in range(Stack[-1]):
                    Stack[-2].pop()
                Stack.pop()
    
        elif c[pos] == "*":
            if (type(Stack[-2]) == int and type(Stack[-1]) == int) or \
                (type(Stack[-2]) == str and type(Stack[-1]) == int) or \
                (type(Stack[-2]) == list and type(Stack[-1]) == int):
                Stack[-2] *= Stack[-1]
                Stack.pop()
            elif type(Stack[-2]) == str and type(Stack[-1]) == str:
                Stack[-2] = "".join([i*len(Stack[-1]) for i in Stack[-2]])
                Stack.pop()

        elif c[pos] == "/":
            if type(Stack[-2]) == int and type(Stack[-1]) == int:
                Stack[-2] /= Stack[-1]
                Stack.pop()
            elif type(Stack[-2]) == list and type(Stack[-1]) == int:
                Stack[-2] = aspl_ssplit(Stack[-2], Stack[-1])
                Stack.pop()

        elif c[pos] == "_":
            if type(Stack[-1]) == int:
                Stack[-1] *= -1
            elif type(Stack[-1]) == list:
                if len(Stack[-1]) == 1:
                    Stack[-1] = list(range(0, Stack[-1][0]+1))
                elif len(Stack[-1]) == 2:
                    Stack[-1] = list(range(Stack[-1][0], Stack[-1][1]+1))
                elif len(Stack[-1]) == 3:
                    Stack[-1] = list(range(Stack[-1][0], Stack[-1][1]+1, Stack[-1][2]))

        elif c[pos] == "%":
            if type(Stack[-1]) == list:
                Stack[-1] = list(set(Stack[-1]))
            elif type(Stack[-2]) == int and type(Stack[-1]) == int:
                Stack[-2] %= Stack[-1]
                Stack.pop()


        elif c[pos] == "<":
            if type(Stack[-2]) == int and type(Stack[-1]) == int:
                Stack.append(int(Stack[-2] < Stack[-1]))
                Stack.pop(-2)
                Stack.pop(-2)
            elif type(Stack[-2]) == list and type(Stack[-1]) == list:
                Stack.append(list_gr(Stack[-2], Stack[-1]))
                Stack.pop(-2)
                Stack.pop(-2)

        elif c[pos] == ">":
            if type(Stack[-2]) == int and type(Stack[-1]) == int:
                Stack.append(int(Stack[-2] > Stack[-1]))
                Stack.pop(-2)
                Stack.pop(-2)
            elif type(Stack[-2]) == list and type(Stack[-1]) == list:
                Stack.append(list_lt(Stack[-2], Stack[-1]))
                Stack.pop(-2)
                Stack.pop(-2)

        elif c[pos] == "=":
            Stack.append(int(Stack[-2] == Stack[-1]))
            Stack.pop(-2)
            Stack.pop(-2)

        elif c[pos] == "[":
            pos += 1
            while c[pos] != "]":
                temp[0] += c[pos]
                pos += 1
            Stack.append([])
            if temp[0] != "":
                for i in temp[0].split(" "):
                    if i.isdigit():
                        Stack[-1].append(int(i))
                    else:
                        Stack[-1].append(i)
                temp[0] = ""

        elif c[pos] == ".":
            if type(Stack[-1]) == list:
                print("[", end = "")
                for i, j in enumerate(Stack[-1]):
                    if i == len(Stack[-1]) - 1:
                        print(f"{j}]", end = "")
                    else:
                        print(f"{j} ", end = "")
                Stack.pop()
            else:
                print(Stack.pop(), end = "")
        elif c[pos] == ",":
            print(chr(Stack.pop()), end = "")

        elif c[pos] == "{":
            pos += 1
            copd = 1
            while copd != 0:
                if c[pos] == "{":
                    copd += 1
                elif c[pos] == "}":
                    copd -= 1
                temp[0] += c[pos]
                pos += 1
            Stack.append(CodeBlock(temp[0]))
            temp[0] = ""
            pos -= 1

        elif c[pos] == "!":
            if type(Stack[-1]) == CodeBlock:
                aspl_parse(Stack.pop().code)
            elif type(Stack[-1]) == int:
                Stack[-1] = math.factorial(Stack[-1])

        elif c[pos] == "$":
            Stack.append(copy.deepcopy(Stack[-1]))
        elif c[pos] == "&":
            Stack.pop()
        elif c[pos] == "^":
            Stack[-2], Stack[-1] = Stack[-1], Stack[-2]
        elif c[pos] == "`":
            Stack.reverse()

        elif c[pos] == "~":
            Stack.append(int(input()))
        elif c[pos] == "@":
            Stack.append(str(input()))

        elif c[pos] == ":":
            pos += 1
            while c[pos] != " " and c[pos] != "\n" and c[pos] != "!" and c[pos] != "{" and c[pos] != "}":
                temp[0] += c[pos]
                pos += 1
            Variables[temp[0]] = Stack[-1]
            Stack.pop()
            temp[0] = ""
            pos -= 1

        elif c[pos] == ";":
            pos += 1
            while c[pos] != " " and c[pos] != "\n" and c[pos] != "!" and c[pos] != "{" and c[pos] != "}":
                temp[0] += c[pos]
                pos += 1
            Stack.append(Variables[temp[0]])
            temp[0] = ""
            pos -= 1

        elif c[pos] == "?":
            t1 = Stack.pop(-2)
            t2 = Stack.pop(-1)
            aspl_parse(t1.code)
            if Stack[-1] != 0:
                aspl_parse(t2.code)

        elif c[pos] == "#":
            t1 = Stack.pop(-2)
            t2 = Stack.pop(-1)
            aspl_parse(t1.code)
            while Stack[-1] != 0:
                aspl_parse(t2.code)
                aspl_parse(t1.code)

        elif c[pos] == "×":
            if type(Stack[-1]) == list:
                Stack[-1] = sum(Stack[-1])
            elif type(Stack[-2]) == int and type(Stack[-1]) == int:
                Stack[-2] **= Stack[-1]

        elif c[pos] == "÷":
            if type(Stack[-1]) == list:
                Stack[-1] = random.choice(Stack[-1])
            elif type(Stack[-2]) == int and type(Stack[-1]) == int:
                Stack[-2] = random.randint(Stack[-2], Stack[-1])
                Stack.pop()

        elif c[pos] == "¬":
            pos += 1
            while c[pos] != " ":
                temp[0] += c[pos]
                pos += 1
            if temp[0] == "and":
                Stack[-2] = Stack[-2] and Stack[-1]
                Stack.pop()
            elif temp[0] == "neq":
                Stack[-2] = Stack[-2] != Stack[-1]
                Stack.pop()
            elif temp[0] == "round":
                Stack[-1] = round(Stack[-1])
            temp[0] = ""


        pos += 1
#    print(Stack)

aspl_parse(code)