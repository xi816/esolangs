class CodeBlock:
    def __init__(self, code):
        self.code = code

    def __repr__(self):
        return f"{'{'+self.code+'}'}"